//
//  p_5.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/17.
//

#include <stdio.h>
//int main(int argc, const char * argv[]) {
//    int i, j;
//    for (i=0; i<8; i++) {
//        for (j=0; j<8; j++) {
//            if ((i+j) % 2 == 0) {
//                printf("🌹");
//            } else {
//                printf("🤍");
//            }
//        }
//        printf("\n");
//    }
//}
