////
////  p_6.c
////  learn-c
////
////  Created by 0x2ab70001b1 on 2025/4/17.
////
//
//#include <stdio.h>
//int main(int argc, const char * argv[]) {
//    int i, j;
//    
//    printf("**\n"); /*输出两个笑脸*/
//    for (i = 1; i < 10; i++) {
//        for (j = 1; j <= i; j++) {
//            printf("**");
//        }
//        printf("\n"); /* 每一行后换行 */
//    }
////    int i,j;
////        printf("**\n"); /*输出两个笑脸*/
////        for(i=1;i<11;i++)
////        {
////            for(j=1;j<=i;j++)
////                printf("**");
////            printf("\n");
////        }
//    return 0;
//}
