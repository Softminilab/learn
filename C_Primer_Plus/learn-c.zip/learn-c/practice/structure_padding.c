//
//  structure_padding.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/22.
//

#include <stdio.h>

// https://www.geeksforgeeks.org/structure-member-alignment-padding-and-data-packing/

// Alignment requirements
// (typical 32 bit machine)

// char         1 byte
// short int    2 bytes
// int          4 bytes
// double       8 bytes

// structure A
typedef struct structa_tag {
    char c;
    short int s;
} structa_t;

// structure B
typedef struct structb_tag {
    short int s;
    char c;
    int i;
} structb_t;

// structure C
typedef struct structc_tag {
    char c;
    double d;
    int s;
} structc_t;

// structure D
typedef struct structd_tag {
    double d;
    int s;
    char c;
} structd_t;

int main()
{
    printf("sizeof(structa_t) = %lu\n", sizeof(structa_t));
    printf("sizeof(structb_t) = %lu\n", sizeof(structb_t));
    printf("sizeof(structc_t) = %lu\n", sizeof(structc_t));
    printf("sizeof(structd_t) = %lu\n", sizeof(structd_t));

    return 0;
}

/**
 sizeof(structa_t) = 4
 sizeof(char) + 1 (padding) + sizeof(short), 1 + 1 + 2 = 4 bytes.
 
 sizeof(structb_t) = 8
 the structb_t requires , 2 + 1 + 1 (padding) + 4 = 8 bytes.

 sizeof(structc_t) = 24
 sizeof(char) + 7-byte padding + sizeof(double) + sizeof(int) = 1 + 7 + 8 + 4 = 20 bytes. However, the sizeof(structc_t) is 24 bytes. It is because, along with structure members, structure type variables will also have natural alignment. Let us understand it by an example
 
 sizeof(structd_t) = 16
 sizeof(double) + sizeof(int) + sizeof(char) + padding(3) = 8 + 4 + 1 + 3 = 16 bytes
 */
