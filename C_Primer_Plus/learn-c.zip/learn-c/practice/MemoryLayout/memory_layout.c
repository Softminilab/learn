//
//  memory_layout.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/22.
//

#include <stdio.h>
#include <stdlib.h>

int global; // Stored in Data Segment

int main(void) {
    static int i = 100; // Stored in Data Segment
    int local_var = 10; // Stored in the stack
    return 0;
}

// https://www.geeksforgeeks.org/memory-layout-of-c-program/
