//
//  variadic_functions.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/24.
//

#include <stdio.h>
#include <stdarg.h>

void print(int n, ...) {
    va_list args;
    va_start(args, n);
    for (int i = 0; i < n; i++) {
        printf("%d ", va_arg(args, int));
    }
    printf("\n");
    va_end(args);
}

int main(int argc, const char *argv[]) {
    print(5, 1, 2, 3, 4, 5);
    return 0;
}
