//
//  h_1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/22.
//

#include <stdio.h>

int main(int argc, const char *argv[]) {
    long char_count = 0;
    int ch;
    
    while ((ch = getchar()) != EOF) {
        char_count++;
    }
    printf("%ld\n", char_count);
    
    return 0;
}

// clang h_1.c -o h_1
// echo "xxxxxx" > h.txt
// ./h_1 < h.txt
