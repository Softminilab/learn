//
//  h_2.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/22.
//

#include <stdio.h>
#include <ctype.h>

int main(int argc, const char *argv[]) {
    int upper_count = 0;
    int lower_count = 0;
    int ch;
    
    
    printf("Input characters. Press Ctrl+D (Linux/macOS) or Ctrl+Z then Enter (Windows) to signify EOF.\n");
    printf("--------------------------------------------------------------------------------------\n");
    
    while ((ch = getchar()) != EOF) {
        if (isupper(ch)) {
            upper_count++;
        } else {
            lower_count++;
        }
    }
    printf("大小总共: %d个\n", upper_count);
    printf("小写总共: %d个\n", lower_count);
    
    return 0;
}
