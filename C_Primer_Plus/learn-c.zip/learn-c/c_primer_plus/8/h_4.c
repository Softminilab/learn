#include <stdio.h>
#include <ctype.h>  // For isalpha(), isspace(), ispunct()
#include <stdbool.h> // For bool, true, false (C99 standard and later)

int main(void) {
    int ch;
    long num_letters = 0;
    long num_words = 0;
    bool in_word = false; // 标记当前是否在单词内部

    printf("请输入文本 (按 Ctrl+D 或 Ctrl+Z 后回车结束输入):\n");

    while ((ch = getchar()) != EOF) {
        // 检查是否是字母
        if (isalpha(ch)) {
            num_letters++; // 统计字母数
            if (!in_word) {
                in_word = true; // 开始一个新单词
                num_words++;    // 单词数增加
            }
        } else {
            // 如果不是字母 (可能是空格、标点或其他)
            // 并且我们之前在单词内部，那么这个单词结束了
            if (in_word) {
                in_word = false;
            }
            // 注意: ispunct(ch) 可以用来特别识别标点符号，
            // 但对于这个问题的逻辑，只要不是字母，就认为它分隔了单词，
            // 并且它本身不计入字母数。
            // 如果题目要求标点符号也算作单词的一部分(但不是字母)，逻辑会更复杂。
            // 但题目说“标点符号也不应该统计”，意味着它既不是字母，也分隔单词。
        }
    }

    // 输出结果
    if (num_words > 0) {
        double avg_letters_per_word = (double)num_letters / num_words;
        printf("\n--- 报告 ---\n");
        printf("总字母数: %ld\n", num_letters);
        printf("总单词数: %ld\n", num_words);
        printf("平均每个单词的字母数: %.2f\n", avg_letters_per_word);
    } else {
        printf("\n未检测到任何单词。\n");
    }

    return 0;
}
