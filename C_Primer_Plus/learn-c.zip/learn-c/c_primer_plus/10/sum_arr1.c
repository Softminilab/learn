//
//  sum_arr1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/27.
//

#include <stdio.h>

#define SIZE 10

int sum(int *ary, int n);
int sump(int * start, int * end);

int main(int argc, const char *argv[]) {
    int number[SIZE] = {20, 10, 5, 39, 4, 16, 19, 26,  31, 20 };
    long total;
    total = sum(number, SIZE);
    printf("The total number of number is %ld.\n", total);
    printf("The size of marbles is %zd bytes.\n", sizeof number);
    long total2 = sump(number, number + SIZE);
    printf("The total number of number2 is %ld.\n", total2);
}

int sum(int *ary, int n) {
    printf("The size of ar is %zd bytes.\n", sizeof ary);
    
    int total = 0;
    for (int i = 0; i<n; i++) {
        total += ary[i];
    }
    return total;
}

int sump(int * start, int * end) {
    int total = 0;
    while (start < end) {
        total += *start;
        start++; // 表达式start++递增指针变量start，使其指 向数组的下一个元素。因为start是指向int的指针，start递增1相当于其值递增 int类型的大小
    }
    return total;
}
