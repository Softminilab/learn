//
//  q_13.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/29.
//

#include <stdio.h>

//13.下面有两个函数原型:
//void show(const double ar[], int n);     // n是数组元素的个数
//void show2(const double ar2[][3], int n);  // n是二维数组的行数
//a.编写一个函数调用，把一个内含8、3、9和2的复合字面量传递给 show()函数。
//b.编写一个函数调用，把一个2行3列的复合字面量(8、3、9作为第1 行，5、4、1作为第2行)传递给show2()函数。

void show(const double ar[], int n);
void show2(const double ar2[][3], int n);

int main(void) {
    show((int[4]){8,3,9,2}, 4);
    show2((int [][3]){{8,3,9}, {5,4,1}}, 2);
    return 0;
}

void show(const double ar[], int n) {
    
}

void show2(const double ar2[][3], int n) {
    
}
