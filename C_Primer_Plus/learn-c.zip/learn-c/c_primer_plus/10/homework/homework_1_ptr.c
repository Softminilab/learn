//
//  homework_1_ptr.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/29.
//
#include <stdio.h>
#define MONTHS 12   // 一年的月份数
#define YEARS  5    // 年数
int main(void)
{
    // 用2010~2014年的降水量数据初始化数组
    const float rain[YEARS][MONTHS] =
    {
        { 4.3, 4.3, 4.3, 3.0, 2.0, 1.2, 0.2, 0.2, 0.4, 2.4, 3.5,  6.6 },
        { 8.5, 8.2, 1.2, 1.6, 2.4, 0.0, 5.2, 0.9, 0.3, 0.9, 1.4,  7.3 },
        { 9.1, 8.5, 6.7, 4.3, 2.1, 0.8, 0.2, 0.2, 1.1, 2.3, 6.1,  8.4 },
        { 7.2, 9.9, 8.4, 3.3, 1.2, 0.8, 0.4, 0.0, 0.6, 1.7, 4.3,  6.2 },
        { 7.6, 5.6, 3.8, 2.8, 3.8, 0.2, 0.0, 0.0, 0.0, 1.3, 2.6,  5.2 }
    };
    
    const float (*year_ptr)[MONTHS];
    const float *month_ptr;
    
    float subtot, total;
    total = 0;
    printf(" YEAR   RAINFALL  (inches)\n");
    for (year_ptr = rain; year_ptr < rain + YEARS; year_ptr++) {
        subtot = 0;
        // 遍历当前年的每个月
        // *year_ptr 是当前行 (一个包含 MONTHS 个 float 的数组)
        // 当 *year_ptr 用在表达式中时，它会衰变为指向该行第一个元素的指针
        for (month_ptr = *year_ptr; month_ptr < *year_ptr + MONTHS; month_ptr++)
            subtot += *month_ptr;
        printf("%5td %15.1f\n", 2010 + (year_ptr - rain), subtot);
        total += subtot;  // 5年的总降水量
    }
    
    printf("\nThe yearly average is %.1f inches.\n\n", total /  YEARS);
    printf ("MONTHLY AVERAGES: \n\n") ;
    printf("Jan Feb  Mar  Apr  May  Jun  Jul  Aug  Sep Oct ");
    printf(" Nov  Dec\n");

    int month_idx, year_idx; // 使用索引来辅助计算

    for (month_idx = 0; month_idx < MONTHS; month_idx++) {
        // 每个月，5年的总降水量
        subtot = 0;
        for (year_idx = 0; year_idx < YEARS; year_idx++)
            subtot += *(*(rain + year_idx) + month_idx);
        printf("%4.1f ", subtot / YEARS);
    }
    
    /*
     ************************
     for (month_idx = 0; month_idx < MONTHS; month_idx++) {
        subtot = 0;
        // 遍历每一年，累加当前月份的降水量
        for (year_idx = 0; year_idx < YEARS; year_idx++) {
             // (rain + year_idx) 指向第 year_idx 行
             // *(rain + year_idx) 是第 year_idx 行 (一个数组)
             // (*(rain + year_idx)) + month_idx 指向第 year_idx 行的第 month_idx 个元素
             // *(*(rain + year_idx) + month_idx) 是该元素的值
             // 或者更直观地，可以认为 rain[year_idx] 是一个指向 rain[year_idx][0] 的指针
             // 所以 *(rain[year_idx] + month_idx) 也是一种写法
             // 这里我们用 rain 本身作为基地址，通过偏移来访问
             
             // 方法1: 使用二维数组的指针算术
             // year_ptr 再次指向 rain 的开头，然后偏移 year_idx 行
             // month_ptr 指向 (rain + year_idx) 这一行的第 month_idx 个元素
             month_ptr = (*(rain + year_idx)) + month_idx;
             subtot += *month_ptr;
             
             // 方法2: (更直接的指针算术表达 rain[year_idx][month_idx])
             // subtot += *(*(rain + year_idx) + month_idx);

             // 方法3: 也可以将 rain 视为一个扁平的 float 数组
             // const float *flat_ptr = (const float *)rain;
             // subtot += *(flat_ptr + year_idx * MONTHS + month_idx);
        }
        printf("%4.1f ", subtot / YEARS);
     }
     ************************
     */
    
    printf("\n");
    return 0;
}
