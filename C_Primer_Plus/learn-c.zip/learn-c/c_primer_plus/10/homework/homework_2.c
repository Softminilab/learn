//
//  homework_2.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/29.
//

#include <stdio.h>

void copy_arr(double target[], const double source[], int num_elements);
void copy_ptr(double *target, const double *source, int num_elements);
void copy_ptrs(double *target, const double *source_start, const double *source_end);

int main(void) {
    double source[5] = {1.1, 2.2, 3.3, 4.4, 5.5};
    
    double target1[5];
    double target2[5];
    double target3[5];
    
    copy_arr(target1, source, 5);
    
    copy_ptr(target2, source, 5);
    
    copy_ptrs(target3, source, source + 5);
    return 0;
}

void copy_arr(double target[], const double source[], int num_elements) {
    for (int i=0; i<num_elements; i++) {
        target[i] = source[i];
    }
}

void copy_ptr(double *target, const double *source, int num_elements) {
    for (int i=0; i<num_elements; i++) {
        *(target+i) = *(source+i);
    }
}

void copy_ptrs(double *target, const double *source_start, const double *source_end) {
    for (const double *ptr=source_start; ptr<source_end; ptr++) {
        *target++ = *ptr;
    }
}
