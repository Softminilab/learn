//
//  homework_8.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/4.
//

#include <stdio.h>
#include "print_array.h"

void copy_arr(double target[], const double source[], int num_elements);

int main(void) {
    const int SIZE = 7;
    double source_array[SIZE] = {1,2,3,4,5,6,7};
        
    double target_array[3];
    copy_arr(target_array, &source_array[2], 3);
    print_double_array(target_array, 3);
    return 0;
}

void copy_arr(double target[], const double source[], int num_elements) {
    for (int i = 0; i < num_elements; i++) {
        target[i] = source[i];
    }
}
