//
//  homework_3.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/30.
//

#include <stdio.h>
int get_max(int ary[], int size);
int get_max_ptr_fixed_v1(const int *ary, int size) ;

int main(void) {
    printf("******************\n");
    printf("get max with arry\n");
    int ary[] = {1,3,4,5,6};
    int max = get_max(ary, 5);
    printf("max %d\n", max);
    
    
    int ary2[] = {1,2,4,5,10};
    int max2 = get_max(ary2, 5);
    printf("max2 %d\n", max2);
    
    printf("\n******************\n");
    printf("get max with ary ptr\n");
    int ary3[] = {1,-2,4,5,10};
    int max3 = get_max_ptr_fixed_v1(ary3, 5);
    printf("max3 %d\n", max3);
    return 0;
}

int get_max(int ary[], int size) {
    if (size < 0 || ary == NULL) {
        return -1;
    }
    
    int i;
    int tmp = ary[0];
    for (i=1; i<size; i++) {
        if (ary[i] > tmp) {
            tmp = ary[i];
        }
    }
    return tmp;
}

// 修正版本 1：使用一个临时变量存储最大值（类似 get_max 但用指针访问）

int get_max_ptr_fixed_v1(const int *ary, int size) { // 使用 const 防止修改
    if (size <= 0 || ary == NULL) {
        // Handle error, e.g., return INT_MIN or assert
        return -1; // Placeholder for error
    }

    int max_val = *ary; // 假设第一个元素的值是最大值，存入普通变量
                       // *ary 等价于 ary[0]
    for (int i = 1; i < size; i++) {
        if (*(ary + i) > max_val) { // *(ary + i) 等价于 ary[i]
            max_val = *(ary + i);
        }
    }
    return max_val;
}

// 修正版本 2：使用指针迭代，并将最大值存在一个普通变量中

int get_max_ptr_fixed_v2(const int *ary, int size) {
    if (size <= 0 || ary == NULL) {
        return -1;
    }

    const int *ptr = ary;      // 指针用于迭代
    int max_val = *ptr;        // 用第一个元素的值初始化 max_val
    const int *end_ptr = ary + size; // 指向数组末尾之后

    ptr++; // 从第二个元素开始比较
    while (ptr < end_ptr) {
        if (*ptr > max_val) {
            max_val = *ptr;
        }
        ptr++;
    }
    return max_val;
}
