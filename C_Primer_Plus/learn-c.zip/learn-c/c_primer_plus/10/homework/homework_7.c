//
//  homework_7.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/3.
//

#include <stdio.h>
#include "print_array.h"

void copy_arr(double target[], const double source[], int num_elements);

int main(void) {
    // 定义二维数组的维度
    const int ROWS = 3;
    const int COLS = 4;
    
    // 1. 初始化一个double类型的二维数组 (源数组)
    double source_2d_array[ROWS][COLS] = {
        {1.1, 1.2, 1.3, 1.4},
        {2.1, 2.2, 2.3, 2.4},
        {3.1, 3.2, 3.3, 3.4}
    };
    
    double target_2d_array[ROWS][COLS];
    
    for (int i = 0; i < ROWS; i++) {
        // source_2d_array[i] 是指向第 i 行首元素的指针
        // target_2d_array[i] 是指向目标数组第 i 行首元素的指针
        // COLS 是每行（子数组）的元素数量
        copy_arr(target_2d_array[i], source_2d_array[i], COLS);
        // 如果使用 copy_ptr:
        // copy_ptr(target_2d_array[i], source_2d_array[i], COLS);
        // 如果使用 copy_ptrs:
        // const double *source_row_start = source_2d_array[i];
        // const double *source_row_end = source_2d_array[i] + COLS; // 指向行尾的下一个位置
        // copy_ptrs(target_2d_array[i], source_row_start, source_row_end);
    }
    
    print_2d_array(ROWS, COLS, source_2d_array);
    
    print_2d_array(ROWS, COLS, target_2d_array);

    return 0;
}

void copy_arr(double target[], const double source[], int num_elements) {
    for (int i = 0; i < num_elements; i++) {
        target[i] = source[i];
    }
}
