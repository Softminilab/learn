//
//  homework_5.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/2.
//

#include <stdio.h>
#include <math.h>  // For nan() or NAN

double get_diff_max_min(double *ary, int size);
int main(void) {
    double arr1[] = {1.0, 5.5, 2.1, 8.0, 3.3};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    double diff1 = get_diff_max_min(arr1, size1);
    if (!isnan(diff1)) { // 检查是否是 NaN
        printf("Array 1: Max-Min difference = %f\n", diff1); // 预期: 8.0 - 1.0 = 7.0
    }
    
    double arr2[] = {10.0, -2.5, 0.0, 5.0};
    int size2 = sizeof(arr2) / sizeof(arr2[0]);
    double diff2 = get_diff_max_min(arr2, size2);
    if (!isnan(diff2)) {
        printf("Array 2: Max-Min difference = %f\n", diff2); // 预期: 10.0 - (-2.5) = 12.5
    }
    
    double arr3[] = {7.0};
    int size3 = sizeof(arr3) / sizeof(arr3[0]);
    double diff3 = get_diff_max_min(arr3, size3);
    if (!isnan(diff3)) {
        printf("Array 3: Max-Min difference = %f\n", diff3); // 预期: 7.0 - 7.0 = 0.0
    }
    
    double arr4[] = {}; // 空数组
    int size4 = 0;
    double diff4 = get_diff_max_min(arr4, size4); // 会触发错误处理
    if (!isnan(diff4)) {
        printf("Array 4: Max-Min difference = %f\n", diff4);
    }
    
    
    double arr5[] = {5.0, 5.0, 5.0};
    int size5 = sizeof(arr5) / sizeof(arr5[0]);
    double diff5 = get_diff_max_min(arr5, size5);
    if (!isnan(diff5)) {
        printf("Array 5: Max-Min difference = %f\n", diff5); // 预期: 5.0 - 5.0 = 0.0
    }
    return 0;
}

double get_diff_max_min(double *ary, int size) {
    if (size <= 0) {
        fprintf(stderr, "Error: Array size must be positive.\n");
        return -1;// 或者返回 0.0，或者其他错误处理方式
    }
    
    double *ptr_max = ary;
    double *ptr_min = ary;
    
    for (int i=1; i<size; i++) {
        if (*(ary+i) > *ptr_max) {
            ptr_max = ary+i;
        }
        if (*(ary+i) < *ptr_min) {
            ptr_min = ary+i;
        }
    }
    printf("Max %f\n", *ptr_max);
    printf("Min %f\n", *ptr_min);
    return *ptr_max - *ptr_min;
}
