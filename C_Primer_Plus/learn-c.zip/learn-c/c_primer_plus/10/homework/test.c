//
//  test.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/2.
//

#include <stdio.h>

int main(void) {
    int score = 95;         // 变量 score，假设它在内存地址 0xAAA0
    int *ptr_to_score;      // 声明一个指向 int 的指针 ptr_to_score

    ptr_to_score = &score;  // 将 score 的地址 (0xAAA0) 赋值给 ptr_to_score
                            // 现在 ptr_to_score 的值是 0xAAA0

    printf("score 的值是: %d\n", score);
    printf("score 的内存地址是: %p\n", &score); // %p 用来打印地址

    printf("ptr_to_score 存储的地址是: %p\n", ptr_to_score);
    printf("通过 ptr_to_score 访问到的值是: %d\n", *ptr_to_score); // 解引用

    // 通过指针修改原变量的值
    *ptr_to_score = 100; // 相当于去 ptr_to_score 指向的地址 (0xAAA0)，把那里的值改成 100
    printf("修改后，score 的值是: %d\n", score); // score 的值会变成 100
    
    score = 101;

    printf("修改后，score 的值是: %d\n", score);
    printf("修改后，ptr_to_score 的值是: %d\n", *ptr_to_score);
    
    return 0;
}
