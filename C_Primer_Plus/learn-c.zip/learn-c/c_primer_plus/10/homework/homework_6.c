//
//  homework_6.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/3.
//

#include <stdio.h>
#include "print_array.h"

void reverse_double_array(double *ary, int size);

// 测试程序
int main(void) {
    double arr1[] = {1.0, 2.5, 3.7, 4.2, 5.9};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);

    printf("Original array 1: ");
    print_double_array(arr1, size1);

    reverse_double_array(arr1, size1);

    printf("Reversed array 1: ");
    print_double_array(arr1, size1); // 预期: 5.90 4.20 3.70 2.50 1.00

    printf("\n");

    double arr2[] = {10.1, 20.2, 30.3, 40.4};
    int size2 = sizeof(arr2) / sizeof(arr2[0]);

    printf("Original array 2: ");
    print_double_array(arr2, size2);

    reverse_double_array(arr2, size2);

    printf("Reversed array 2: ");
    print_double_array(arr2, size2); // 预期: 40.40 30.30 20.20 10.10

    printf("\n");

    double arr3[] = {5.0};
    int size3 = sizeof(arr3) / sizeof(arr3[0]);
    printf("Original array 3: ");
    print_double_array(arr3, size3);
    reverse_double_array(arr3, size3);
    printf("Reversed array 3: ");
    print_double_array(arr3, size3); // 预期: 5.00 (单个元素不变)

    printf("\n");

    double *arr4 = NULL;
    int size4 = 0;
    printf("Original array 4: ");
    print_double_array(arr4, size4);
    reverse_double_array(arr4, size4);
    printf("Reversed array 4: ");
    print_double_array(arr4, size4); // 预期: Array is empty or NULL.


    return 0;
}

void reverse_double_array(double *ary, int size) { // 改个更明确的名字

    if (ary == NULL || size <= 1) { // 处理空指针和不需要倒序的情况
            return;
    }
    
    int i = 0;
    int j = size - 1;
    double tmp;
    for (; i < j; i++, j--) {
        tmp = ary[i];
        ary[i] = ary[j];
        ary[j] = tmp;
    }
}
