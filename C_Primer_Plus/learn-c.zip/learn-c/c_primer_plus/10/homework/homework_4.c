//
//  homework_4.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/30.
//

#include <stdio.h>
int get_max_index(double ary[], int size);
int get_max_ptr_index(double *ary, int size);
void qw(void);

int main(void) {
    printf("******************\n");
    printf("get max index with arry\n");
    double ary[] = {1,3,4,5,6,1};
    int indx = get_max_index(ary, 5);
    printf("indx %d\n", indx);
    
    
//    printf("\n******************\n");
//    printf("get max index with ptr ary\n");
//    double ary3[] = {1,-2,4,5,10};
//    int index3 = get_max_ptr_index(ary3, 5);
//    printf("index3 %d\n", index3);
    
    qw();
    return 0;
}

int get_max_index(double ary[], int size) {
    int i;
    double tmp = ary[0];
    int idx = 0;
    for (i=1; i<size; i++) {
        if (ary[i] > tmp) {
            tmp = ary[i];
            idx = i;
        }
    }
    return idx;
}

//int get_max_ptr_index(double *ary, int size) {
//    int i;
//    double *tmp_ptr = ary;
//    int idx = 0;
//    for (i=1; i<size; i++) {
//        if (*(ary+i) > *tmp_ptr) {
//            *tmp_ptr = *(ary+i);
//            idx = i;
//        }
//    }
//    return idx;
//}

int get_max_ptr_index2(double *ary, int size) {
    int i;
    double *tmp_ptr = ary;
    
    int idx = 0;
    for (i=1; i<size; i++) {
        if (*(ary+i) > *tmp_ptr) {
            tmp_ptr = ary+i;
            idx = i;
        }
    }
    return idx;
}

void qw(void) {
    double a = 10;
    double *tmp_ptr = &a;
    *tmp_ptr = 23;
    printf("tmp_ptr %f", *tmp_ptr);
}
