//
//  homework_9.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/4.
//

#include <stdio.h>
#include "print_array.h"

void copy_2d_array(int rows, int cols, double source_2d_array[][cols],double target_2d_array[][cols]);

int main(void) {
    const int cols = 5;
    const int rows = 3;
    double source_array[rows][cols] = {
        {1.0, 2.0, 3.0, 4.0, 5.0},
        {6,7,8,9,10},
        {11,12,13,14,15}
    };
    double target_array[rows][cols];
    copy_2d_array(rows, cols, source_array, target_array);
    print_2d_array(rows, cols, target_array);
    return 0;
}

void copy_2d_array(int rows, int cols, double source_2d_array[][cols],double target_2d_array[][cols]) {
    if (rows <= 0 || cols <= 0 || source_2d_array == NULL || target_2d_array == NULL) {
        // 处理错误，例如打印信息或直接返回
        fprintf(stderr, "Invalid arguments for copy_2d_array.\n");
        return;
    }
    
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            target_2d_array[i][j] = source_2d_array[i][j];
        }
    }
}
