//
//  p.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/29.
//

#include <stdio.h>

int main(void){
    int *ptr;
    int fort[2][2] = { {12}, {14, 16}};
    ptr = fort[0];
    printf("%d %d\n", *ptr, *(ptr + 2));
    return 0;
}

void t(void) {
    int (*ptr)[2];
    int torf[2][2] = {12, 14, 16};
    // torf[0][0]=12, torf[0][1]=14,
    // torf[1][0]=16, torf[1][1]=0
    
    ptr = torf;
}

// 假设编译器支持C99/C11标准，声明一个内含100个int类型值的数组， 并初始化最后一个元素为-1，其他元素不考虑
// int lots[100] = { [99] = -1};


// 假设编译器支持C99/C11标准，声明一个内含100个int类型值的数组， 并初始化下标为5、10、11、12、3的元素为101，其他元素不考虑
// int pots[100] = { [5] = 101, [10] = 101,101, 101, 101};


// float rootbeer[10],
// things[10][5],
// *pf,
// value = 2.2;
// int i = 3;

// double trots[20];
//void process(double ar[], int n);
//void processvla(int n, double ar[n]);
//process(trots, 20);
//processvla(20, trots);

// short clops[10][30];
//void process2(short ar[30], int r);
//void processvla2(int r, int c, short ar[r][c]);
//process2(clops, 10);
//processvla2(10, 30, clops);

//long shots[5][10][15];
//void process3(long ar3[10][15], int n);
//void process3vla(int n, int m,int k, long ar3[n][m][k]);
//process3(shots, 5);
//process3vla(5, 10, 15, shots);
