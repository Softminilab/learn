//
//  ptr_ops.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/28.
//

#include <stdio.h>
#define STAR "***********************"
#define SIZE 5

int main(void) {
    int urn[5] = {100, 200, 300, 400, 500};
    
    printf("\n%s\n", STAR);
    for (int i=0; i<SIZE; i++) {
        printf("urn %d element value is %d, address is %p\n", i + 1, urn[i], &urn[i]);
    }
    
    int *ptr1, *ptr2, *ptr3;
    ptr1 = urn; // 把一个地址赋给指针
    ptr2 = &urn[2];  // 把一个地址赋给指针
    
    printf("\n%s\n", STAR);
    if (ptr1 == ptr2) {
        printf("true");
    } else {
        printf("false");
    }
    printf("\n%s\n", STAR);
    // 解引用指针，以及获得指针的地址
    printf("pointer value, dereferenced pointer, pointer address: \n");
    printf("ptr1 = %p, *ptr1 =%d, &ptr1 = %p\n", ptr1, *ptr1, &ptr1);
    printf("\n%s\n", STAR);
    // 指针加法
    ptr3 = ptr1 + 4;
    printf("ptr3 value is %d, address is %p %p", *ptr3, ptr3, &ptr3);
    /*
     *ptr3：这是解引用操作。它获取 ptr3 所指向的内存地址中存储的值。因为 ptr3 指向 urn[4]，所以 *ptr3 就是 urn[4] 的值，即 500。
     ptr3：这是指针变量 ptr3 本身存储的值。它存储的是一个内存地址，这个地址是 urn[4] 的地址（即 &urn[4]）。
     &ptr3：这是取地址操作。它获取的是指针变量 ptr3 自身在内存中的地址。
     
     核心区别：
     ptr3 (变量的值)：是它所指向的内存位置的地址。在这个例子中，是 urn[4] 的地址。
     &ptr3 (变量的地址)：是存储 ptr3 这个指针变量本身的内存位置的地址。
     打个比方：
     想象你有一张纸条（ptr3），上面写着一个房子的地址（比如 "人民路123号"，这就是 urn[4] 的地址）。
     *ptr3：是你根据纸条上的地址找到那个房子，然后看房子里有什么（值是 500）。
     ptr3：是纸条上写着的那个房子的地址（"人民路123号"，即 &urn[4]）。
     &ptr3：是你这张纸条本身放在你书桌上的哪个位置（比如 "书桌左上角抽屉里"，这是指针变量 ptr3 自己的存储地址）。
     纸条上写的地址（ptr3 的值）和纸条本身的位置（&ptr3）显然是两个不同的东西。
     所以，ptr3（它指向的 urn[4] 的地址）和 &ptr3（指针变量 ptr3 自身的地址）是不同的地址，这是完全正常的。
     */
    
    printf("\n%s\n", STAR);
    printf("adding an int to a pointer: \n");
    printf("ptr1 + 4 = %p, *(ptr1 + 4) = %d\n", ptr1 + 4, *(ptr1 + 4));
    printf("\n%s\n", STAR);
    ptr1++;         // 递增指针
    printf("\nvalues after ptr1++: \n");
    printf("ptr1 = %p, *ptr1 =%d, &ptr1 = %p\n", ptr1, *ptr1, &ptr1);
    printf("\n%s\n", STAR);
    return 0;
}
