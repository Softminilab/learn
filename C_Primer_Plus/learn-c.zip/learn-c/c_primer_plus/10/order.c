//
//  order.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/27.
//

#include <stdio.h>

int data[2] = { 100, 200 };
int moredata[2] = { 300, 400 };
int main(void) {
    int *p1, *p2, *p3;
    p1 = p2 = data;
    p3 = moredata;
    
    printf(" *p1 = %d,  *p2 = %d,  *p3 = %d\n",*p1, *p2, *p3);
    printf("*p1++ = %d, *++p2 = %d, (*p3)++ = %d\n",*p1++, *++p2, (*p3)++);
    // *p1++ 先把指针位置的值取出来，然后再递增指针
    // *++p 先递增指针，再使用指 针指向位置上的值
    // (*p3)++)，则先使用 p3 指向的值，再递增该 值，而不是递增指针
    printf(" *p1 = %d,  *p2 = %d,  *p3 = %d\n",*p1, *p2, *p3);
    
    return 0;
}
