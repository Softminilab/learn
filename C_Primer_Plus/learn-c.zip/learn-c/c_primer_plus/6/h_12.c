#include <stdio.h>
#include <math.h> // 如果要用 pow(-1, k) 来处理符号，虽然有更简单的方法

int main(int argc, const char *argv[]) {
    int num;

    while (1) { // 无限循环，直到用户输入0或负值
        printf("请输入一个数(项数，输入0或负值时结束): ");
        scanf("%d", &num);

        if (num <= 0) {
            printf("输入 %d，程序结束。\n", num);
            break; // 结束循环
        }

        // --- 计算序列1: 1.0 + 1.0/2.0 + 1.0/3.0 + ... ---
        double sum_series1 = 0.0;
        for (int i = 1; i <= num; i++) {
            sum_series1 += 1.0 / i;
        }

        // --- 计算序列2: 1.0 - 1.0/2.0 + 1.0/3.0 - ... ---
        double sum_series2 = 0.0;
        double sign = 1.0; // 用于控制符号 +/-
        for (int i = 1; i <= num; i++) {
            // 方法1: 直接使用 sign 变量
            sum_series2 += sign * (1.0 / i);
            sign *= -1.0; // 切换符号

            // 方法2: 根据 i 的奇偶性 (更符合提示)
            // if (i % 2 == 1) { // 奇数项 (1, 3, 5...) 为正
            //     sum_series2 += 1.0 / i;
            // } else { // 偶数项 (2, 4, 6...) 为负
            //     sum_series2 -= 1.0 / i;
            // }

            // 方法3: 使用 pow (效率较低，不推荐)
            // sum_series2 += pow(-1, i + 1) * (1.0 / i); // i+1 或 i-1 使得第一项为正
        }

        printf("计算 %d 项后:\n", num);
        printf("序列1 (1 + 1/2 + 1/3 + ...) 的和: %f\n", sum_series1);
        printf("序列2 (1 - 1/2 + 1/3 - ...) 的和: %f\n", sum_series2);
        printf("------------------------------------\n");
    }

    printf("Done.\n");
    return 0;
}
