//
//  h_13.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/21.
//

#include <stdio.h>
#include <math.h>

int main(int argc, const char *argv[]) {
    
    int numbers[8];
    for (int i=1; i<=8; i++) {
        numbers[i-1] = pow(2, i);
    }
    
    int i = 0;
    do {
        printf("%d\n", numbers[i]);
        i++;
    } while (i < 8);
    return  0;
}
