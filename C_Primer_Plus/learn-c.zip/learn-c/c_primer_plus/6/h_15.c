//
//  h_15.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/21.
//

#include <stdio.h>
#include <string.h> // 虽然我们这里不直接用strlen，但了解它有帮助

#define MAX_CHARS 255 // 最大字符数，不包括末尾的 '\0'

int main(int argc, const char *argv[]) {
    char input_line[MAX_CHARS + 1]; // +1 用于存放字符串结束符 '\0'
    int char_count = 0;
    int ch = 0; // 使用 int 类型来接收 getchar() 的返回值，以便正确处理 EOF

    printf("请输入一行字符 (最多 %d 个字符，按 Enter 结束):\n", MAX_CHARS);

    // 读取字符直到换行符、EOF 或达到最大限制
    // getchar() 会读取用户输入的每个字符，包括按下Enter键时产生的换行符 '\n'
    while (char_count < MAX_CHARS && (ch = getchar()) != '\n' && ch != EOF) {
        input_line[char_count] = (char)ch;
         char_count++;
    }

    // 在数组末尾添加字符串结束符
    input_line[char_count] = '\0';

    // 如果输入为空（用户直接按了Enter），char_count会是0
    if (char_count == 0 && ch == '\n') {
        printf("输入为空。\n");
    } else if (ch == EOF && char_count == 0) {
        printf("没有读取到任何输入 (EOF)。\n");
    }
    else {
        printf("倒序输出: ");
        // 从最后一个实际读取的字符开始向前打印
        // char_count 是字符的数量，所以最后一个字符的索引是 char_count - 1
        for (int i = char_count - 1; i >= 0; i--) {
            printf("%c", input_line[i]);
        }
        printf("\n"); // 打印一个换行符，使输出更整洁
    }

    // 如果是因为达到MAX_CHARS而停止，并且最后一个字符不是换行符，
    // 可能输入缓冲区中还有字符。这里简单处理，不清除缓冲区。
    // 在更复杂的程序中，可能需要处理这种情况。
    if (char_count == MAX_CHARS && ch != '\n' && ch != EOF) {
        printf("注意: 输入可能已被截断，因为已达到%d字符的上限。\n", MAX_CHARS);
        // 可以选择清除剩余的输入缓冲区
        // while ((ch = getchar()) != '\n' && ch != EOF);
    }


    return 0;
}
