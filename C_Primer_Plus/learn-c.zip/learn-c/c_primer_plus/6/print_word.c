#include <stdio.h>
#include <string.h> // 为了使用 strlen() 函数

// 这是一个辅助宏，用于将宏参数转换为字符串字面量
// 例如，STR(100) 会变成 "100"
// 这是为了在 scanf 的格式字符串中动态地使用 MAX_WORD_LENGTH
#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)
#define MAX_WORD_LENGTH 100 // 定义单词的最大长度

int main(void) {
    char word[MAX_WORD_LENGTH + 1]; // +1 是为了存储字符串末尾的空字符 '\0'
    int length;
    int i;

    printf("%s", STR_HELPER(100));
    // 提示用户输入单词
    printf("请输入一个单词: ");
    
    // 读取单词
    // 使用 "%99s" 防止缓冲区溢出，确保最多读取 MAX_WORD_LENGTH-1 个字符，
    // 留下空间给末尾的 '\0'
    // scanf 在遇到第一个空白字符（空格、制表符、换行符）时停止读取
    if (scanf("%" STR(MAX_WORD_LENGTH) "s", word) != 1) {
        // STR() 宏用于将数字转换为字符串，这样可以动态设置 scanf 的宽度
        // scanf 返回成功匹配和赋值的项数。如果不是1，则表示输入失败
        printf("读取输入时发生错误。\n");
        return 1; // 返回错误码
    }

    // 计算单词的长度
    length = strlen(word);

    // 如果单词为空，则不进行任何操作
    if (length == 0) {
        printf("你输入的是一个空单词。\n");
        return 0;
    }

    // 倒序打印单词
    printf("倒序打印的单词是: ");
    // 数组的最后一个字符的下标是 length - 1
    // 我们从最后一个字符开始打印，一直到第一个字符（下标为 0）
    for (i = length - 1; i >= 0; i--) {
        printf("%c", word[i]);
    }
    printf("\n"); // 打印一个换行符，使输出更整洁

    return 0; // 程序成功结束
}

