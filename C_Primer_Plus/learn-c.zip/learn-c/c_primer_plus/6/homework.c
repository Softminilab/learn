//
//  homework.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/13.
//

#include <stdio.h>

#define NUMBER 26

void h_1(void) {
    char numbers[NUMBER];
    for (int i = 0; i<NUMBER; i++) {
        numbers[i] = 97 + i;
    }
    
    for (int i = 0; i<NUMBER; i++) {
        printf("%c ", numbers[i]);
    }
    printf("\n");
}

void h_2(void) {
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j <= i; j++) {
            printf("$");
        }
        printf("\n");
    }
}

void h_3(void) {
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%c", 70 - j);
        }
        printf("\n");
    }
}

void h_4(void) {
    char first = 'A';
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%c", first++);
        }
        printf("\n");
    }
}

void h_5(void) {
    for (int i = 0; i < 5; i++) {
        char current_char_asc = 'A';
        for (int j = 0; j <= i; j++) {
            printf("%c", current_char_asc + j);
        }
        
        char peak_char = 'A' + i;
        for (int j = 1; j <= i; j++) { // j 从 1 开始，表示离顶峰的距离
            printf("%c", peak_char - j);
        }
        printf("\n");
    }
}

void h_6(void) {
    printf("请输入上限和下限:");
    int up_data, down_data;
    scanf("%d %d", &up_data, &down_data);
    for (int i = down_data; i <= up_data; i++) {
        printf("%5d %5d %5d\n", i, i * i, i * i * i);
    }
}

int main(int argc, const char *argv[]) {
    //    h_1();
    //    h_2();
    //    h_3();
    //    h_4();
//    h_5();
//    h_6();
    return 0;
}
