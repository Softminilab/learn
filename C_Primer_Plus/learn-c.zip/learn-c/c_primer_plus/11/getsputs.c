//
//  getsputs.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/4.
//

#include <stdio.h>

#define STLEN 81

int main(void)
{
    char words[STLEN];
    puts("Enter a string, please.");
    gets(words); // 典型用法
    printf("Your string twice: \n");
    printf("%s\n", words);
    puts(words);
    puts("Done.");
    return 0;
}
