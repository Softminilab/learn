//
//  fgets1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/4.
//

#include <stdio.h>
// puts()函数会在待输出字符串末尾添加一个换行符，而fputs()不会这样做。

#define STLEN 14
int main(void)
{
    char words[STLEN];
    puts("Enter a string, please.");
    fgets(words, STLEN, stdin);
    printf("Your string twice (puts(), then fputs()):\n");
    puts(words);
    fputs(words, stdout);
    puts("Enter another string, please.");
    fgets(words, STLEN, stdin);
    printf("Your string twice (puts(), then fputs()):\n");
    puts(words);
    fputs(words, stdout);
    puts("Done.");
    return 0;
}
