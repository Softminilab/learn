//
//  char_1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/28.
//

#include <stdio.h>
/* 标准ASCII码的范围是0~127，只需7位二进制数即可表示。通常，char 类型被定义为8位的存储单元，因此容纳标准ASCII码绰绰有余 */

int main(int argc, const char *argv[]) {
    char beep = '\007';
    printf("%c \n", beep);
    _Bool flg = 0;
    return 0;
}
