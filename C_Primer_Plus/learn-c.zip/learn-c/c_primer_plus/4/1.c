//
//  1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/30.
//

#include <stdio.h>
#include <string.h>

int main(int argc, const char *argv[]) {
    char name[40];
    
    printf("请输入你的姓名：");
    scanf("%s", name);
    printf("Your name is %s\n", name);
    printf("Your name length %lu \n", strlen(name));
    
    printf("------------\n");
    printf("He sold the painting for $%2.2f.\n", 2.345e2);
    printf("%c%c%c\n", 'H', 105, '\41');
    return 0;
}

/*
 'x'是一个字符 x
 "x"是一个字符串 x \0
 */
