//
//  5.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/7.
//

#include <stdio.h>
#define BOOK "War and peace"

int main(int argc, const char *argv[]) {
    float cost = 12.99;
    float percent = 80.0;
    
    printf("This copy of \"%s\" sells for $%0.2f.\n", BOOK, cost);
    printf("That is %0.0f%% of list.\n", percent);
    return 0;
}

//int main(int argc, const char *argv[]) {
//    int val;
//    scanf("%d",&val);
//    return 0;
//}
