//
//  print_array.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/3.
//

#include "print_array.h"
#define STAR "************************"

void print_int_array(const int *arr, int size) {
    if (arr == NULL || size <= 0) return;
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n%s\n", STAR);
}

void print_double_array(const double *arr, int size) {
    if (arr == NULL || size <= 0) return;
    for (int i = 0; i < size; i++) {
        printf("%.2f ", arr[i]);
    }
    printf("\n%s\n", STAR);
}

// 辅助函数：打印二维数组
void print_2d_array(int rows, int cols, double arr[rows][cols]) {
    printf("[\n");
    for (int i = 0; i < rows; i++) {
        printf("  [");
        for (int j = 0; j < cols; j++) {
            printf("%.2f", arr[i][j]);
            if (j < cols - 1) {
                printf(", ");
            }
        }
        printf("]");
        if (i < rows - 1) {
            printf(",");
        }
        printf("\n");
    }
    printf("]\n");
}

