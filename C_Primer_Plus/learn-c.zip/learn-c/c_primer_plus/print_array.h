//
//  print_array.h
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/3.
//

#ifndef print_array_h
#define print_array_h

#include <stdio.h>
void print_double_array(const double *arr, int size);
void print_int_array(const int *arr, int size);
void print_2d_array(int rows, int cols, double arr[rows][cols]);
#endif /* print_array_h */
