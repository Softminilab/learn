//
//  homework.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/10.
//

#include <stdio.h>

#define Per_Min 60

void h_1(void) {
    printf("%s\n",__func__);
    int minutes;
    printf("请输入分钟数，当输入的值小于或者等于0就会停止:");
    scanf("%d", &minutes);
    while (minutes > 0) {
        printf("总分钟数为: %d\n", minutes);
        printf("%d 小时, %d 分钟\n", minutes/60, minutes%60);
        printf("请输入分钟数，当输入的值小于或者等于0就会停止:");
        scanf("%d", &minutes);
    }
    printf("退出\n");
    printf("%s\n\n",__func__);
}

void h_2(void) {
    int numer;
    printf("请输入一个数: ");
    scanf("%d", &numer);
    int end_number = numer + 10;
    while (numer <= end_number) {
        printf("%d\t", numer);
        numer++;
    }
}

void h_3(void) {
    int day;
    printf("请输入天数，当输入的值小于或者等于0就会停止:");
    scanf("%d", &day);
    while (day > 0) {
        int weeks = day/7;
        int days = day%7;
        printf("%d days are %d weeks, %d days.\n", day, weeks, days);
        printf("请输入分钟数，当输入的值小于或者等于0就会停止:");
        scanf("%d", &day);
    }
    printf("退出\n");
}

int main(int argc, const char *argv[]) {
//    h_1();
//    h_2();
    h_3();
    return 0;
}
