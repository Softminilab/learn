//
//  review.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/10.
//

#include <stdio.h>

void q_1(void) {
    printf("------q-1 begin--------\n");
    int x = (2+3)*6; // 30
    int y = (12 + 6)/2*3; // 27
    int z = x = (2+3)/4; // 1
    int q = 3+2*(x = 7/2); // 9
    printf("x %d\n", x);
    printf("y %d\n", y);
    printf("z %d\n", z);
    printf("q %d\n", q);
    printf("------q-1 end--------\n");
}

void q_2(void) {
    printf("------%s begin--------\n", __func__);
    int x = (int)3.8 + 3.3; // 6
    int y = (2+3)*10.5; // 5*10.5 -> 52.5 -> 52
    int z = 3/5*22.0; // 13.2 -> 13❌ ✅ 0
    int q = 22.0 * 3 / 5; // 66.0/5 ->13.2 -> 13
    printf("x %d\n", x);
    printf("y %d\n", y);
    printf("z %d\n", z);
    printf("q %d\n", q);
    printf("------%s end--------\n", __func__);
}

void q_3(void) {
    printf("------%s begin--------\n", __func__);
    // 30.0/4.0*5.0
    // 30.0/(4.0*5.0)
    // 30/4*5
    // 30*5/4;
    // 30/4.0*5
    // 30/4*5.0
    printf("a %f\n", 30.0/4.0*5.0);
    printf("b %f\n", 30.0/(4.0*5.0));
    printf("c %d\n", 30/4*5);
    printf("d %d\n", 30*5/4);
    printf("e %f\n", 30/4.0*5);
    printf("f %f\n", 30/4*5.0);
    printf("------%s end--------\n", __func__);
}

void q_4(void) {
    printf("------%s begin--------\n", __func__);
    int sec;
    printf("%d\n", sec);
    printf("------%s end--------\n", __func__);
}

#define FORMAT "%s! C is cool!\n"

void q_6(void) {
    printf("------%s begin--------\n", __func__);
    int num = 10;
    printf(FORMAT,FORMAT); // printf("%s! C is cool!\n","%s! C is cool!\n");
    printf("%d\n", ++num); // 11
    printf("%d\n", num++); // 11
    printf("%d\n", num--); // 12
    printf("%d\n", num); // 11
    printf("------%s end--------\n", __func__);
}

void q_7(void) {
    printf("------%s begin--------\n", __func__);
    int num = 10;
    printf(FORMAT,FORMAT);
    printf("%d\n", ++num); // 11
    printf("%d\n", num++); // 11
    printf("%d\n", num--); // 12
    printf("%d\n", num); // 11
    printf("------%s end--------\n", __func__);
}

void q_8(void) {
    printf("------%s begin--------\n", __func__);
    char c1, c2;
    int diff;
    float num;
    c1 = 'S'; // 83
    c2 = 'O'; // 79
    diff = c1 - c2; // 4
    num = diff; // 4
    printf("%c%c%c:%d %3.2f\n", c1, c2, c1, diff, num);
    printf("------%s end--------\n", __func__);
}

#define TEN 10

void q_9(void) {
    printf("------%s begin--------\n", __func__);
    int n = 0;
    while (n++ < TEN)
    printf("%5d", n);
    printf("\n");
    printf("------%s end--------\n", __func__);
}

void q_10(void) {
    printf("------%s begin--------\n", __func__);
    char n = 'a';
    char end = 'g';
    while (n <= end)
    printf("%5c", n++);
    printf("\n");
    printf("------%s end--------\n", __func__);
}

void q_11(void) {
    printf("------%s begin--------\n", __func__);
    int x = 100;
    while (x++ < 103) {
        printf("@@\n");
        printf("%4d\n", x);
    }
    printf("#####\n");
    printf("%4d\n", x);
    
    printf("------%s end--------\n", __func__);
}

int main(int argc, const char *argv[]) {
    q_1();
    q_2();
    q_3();
    q_4();
    q_6();
    q_7();
    q_8();
    q_9();
    q_10();
    q_11();
    return 0;
}

