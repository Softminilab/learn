//
//  post_pre.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/5/8.
//

#include <stdio.h>

//int main(int argc, const char *argv[]) {
//    int a = 1, b = 1;
//    int a_post, pre_b;
//    a_post = a++; // 先赋值，在自加
//    pre_b = ++b; // 先自加，再赋值
//    printf("a  a_post  b  pre_b \n");
//    printf("%1d %5d %5d %5d\n", a, a_post, b, pre_b);
//    /*
//     output:
//     a  a_post  b  pre_b
//     2     1     2     2
//     */
//    return 0;
//}

int main(int argc, const char *argv[]) {
    int index = 0;
    while (index++ < 2) {
        printf("Index %d\n", index);
    }
    printf("Done\n");
    
    int index2 = 0;
    while (++index2 < 2) {
        printf("index2 %d\n", index2);
    }
    printf("Done\n");
    return 0;
}
