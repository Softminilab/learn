//
//  vlamal.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/5.
//

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int n;
    int * pi;
    scanf("%d", &n);
    pi = (int *) malloc (n * sizeof(int));
    int ar[n];// 变长数组
    pi[2] = ar[2] = -5;
    
    for (int i = 0; i<n; i++) {
        printf("pi[%d] = %d, ar[%d] = %d\n", i, pi[i], i, ar[i]);
    }
    
    volatile const int loc = 10;
    printf("\n");
    printf("\n");
    
    int * p1 = (int *)malloc(n * sizeof(int));
    int * p2 = (int *)calloc(n, sizeof(int));
    for (int i = 0; i<n; i++) {
        printf("p1[%d] = %d, p2[%d] = %d\n", i, p1[i], i, p2[i]);
    }
    return 0;
}
