//
//  rollem.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/5.
//

#include <stdio.h>
#include <stdlib.h>

int rollem(int sides) {
    int roll;
    roll = rand() % sides + 1;
    return roll;
}

