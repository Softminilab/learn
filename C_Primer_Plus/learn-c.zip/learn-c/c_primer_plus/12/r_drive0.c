//
//  r_drive0.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/6/5.
//

#include <stdio.h>
extern unsigned int rand0(void);

int main(void)
{
    int count;
    for (count = 0; count < 5; count++)
        printf("%d\n", rand0());
    return 0;
}
