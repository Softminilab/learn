好的，我们来详细介绍一下 C 语言中的 `union`（联合）。

**1. 什么是 `union`？**

`union` 是 C 语言中的一种用户自定义数据类型，其语法与 `struct`（结构体）类似，但在其成员如何存储在内存中方面存在关键区别。

*   **共享内存 (Shared Memory):** 与 `struct` 中每个成员都占用自己独立的内存位置不同，`union` 的**所有**成员共享**相同**的内存位置。
*   **大小 (Size):** `union` 变量的大小由其**最大**成员的大小决定。编译器会分配足够的内存来容纳最大的成员，所有其他成员都覆盖（overlay）在同一块内存空间上。
*   **活动成员 (Active Member):** 在任何给定时刻，`union` 中只有**一个**成员能够持有有意义的值（即最后被写入数据的那个成员）。向一个成员写入数据会覆盖掉先前由任何其他成员存储的数据。

**2. 语法**

定义和使用 `union` 的语法与 `struct` 非常相似：

```c
#include <stdio.h>
#include <string.h> // 如果使用 strcpy/snprintf 需要包含

// 定义一个名为 'Data' 的联合类型
union Data {
    int i;
    float f;
    char str[20]; // (很可能是)最大的成员
};

int main() {
    // 声明一个联合变量
    union Data data_var;

    // 声明一个指向联合的指针
    union Data *data_ptr;
    data_ptr = &data_var;

    // 使用点 (.) 操作符访问变量的成员
    data_var.i = 10;
    printf("data_var.i: %d\n", data_var.i);

    data_var.f = 220.5f;
    printf("data_var.f: %f\n", data_var.f);
    // 警告：此时访问 data_var.i 将得到垃圾数据或被重新解释的数据
    // printf("data_var.i 在赋值 f 之后: %d\n", data_var.i); // 未定义行为 或 实现定义的行为

    // 使用箭头 (->) 操作符访问指针指向的联合的成员
    // 使用 snprintf 更安全
    snprintf(data_ptr->str, sizeof(data_ptr->str), "Hello Union");
    printf("data_ptr->str: %s\n", data_ptr->str);
    // 警告：此时访问 data_var.f 或 data_var.i 将读取字符串被重新解释后的字节

    // 检查大小
    printf("union Data 的大小: %zu 字节\n", sizeof(union Data)); // %zu 用于打印 size_t 类型
    printf("int 的大小: %zu 字节\n", sizeof(int));
    printf("float 的大小: %zu 字节\n", sizeof(float));
    printf("char[20] 的大小: %zu 字节\n", sizeof(char[20]));

    return 0;
}
```

**3. 工作原理（内存布局）**

想象内存就像一个足够容纳最大物品的盒子：

```
union Data {
    int i;       // 需要 (例如) 4 字节
    float f;     // 需要 (例如) 4 字节
    char str[20]; // 需要 20 字节
};

// 为 'data_var' 分配的内存 (大小 = 20 字节, 基于 str[20]):
// +---------------------------------------------------+
// | 内存块 (20 字节)                                  |
// +---------------------------------------------------+
// ^ 起始地址

// 当你写入 data_var.i = 10;
// +---------------------------------------------------+
// | int 的值 (10) | 未使用的字节                      |
// +---------------------------------------------------+
// ^ 起始地址

// 当你写入 data_var.f = 220.5f;
// +---------------------------------------------------+
// | float 的值 (220.5) | 未使用的字节                 |
// +---------------------------------------------------+
// ^ 起始地址 (先前的 int 值被覆盖)

// 当你写入 snprintf(data_var.str, ..., "Hello");
// +---------------------------------------------------+
// | 'H'|'e'|'l'|'l'|'o'|'\0'| ... 可能是垃圾数据      |
// +---------------------------------------------------+
// ^ 起始地址 (先前的 float 值被覆盖)
```

在向 `data_var.str` 写入数据后访问 `data_var.i`，意味着将 'H', 'e', 'l', 'l' 的 ASCII 字节解释为它们好像是一个整数。这被称为**类型双关 (Type Punning)**，虽然可能，但这通常会导致不可移植或未定义的行为。

**4. 追踪活动成员（非常重要！）**

由于 `union` 本身并不知道哪个成员当前是“有效的”，**追踪哪个成员最后被写入并且应该被读取，这是程序员的责任。**

最常见的方法是将 `union` 与一个 `enum`（枚举）或 `int` 类型的字段配对，通常放在一个包含它们的 `struct` 中。这种模式有时被称为**标记联合 (Tagged Union)** 或 **可辨识联合 (Discriminated Union)**。

```c
#include <stdio.h>
#include <string.h> // 为了 strcpy (或更好的 snprintf)

// 定义联合可能持有的类型
typedef enum {
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_STRING
} DataType;

// 联合本身
union Value {
    int i;
    float f;
    char s[50];
};

// 标记联合结构体
typedef struct {
    DataType type; // 标记，指示哪个成员是活动的
    union Value value; // 存储实际数据的联合
} Variant;

// 根据类型标记打印变体的函数
void printVariant(const Variant *v) {
    switch (v->type) {
        case TYPE_INT:
            printf("变体 (Int): %d\n", v->value.i);
            break;
        case TYPE_FLOAT:
            printf("变体 (Float): %f\n", v->value.f);
            break;
        case TYPE_STRING:
            printf("变体 (String): %s\n", v->value.s);
            break;
        default:
            printf("变体 (未知类型)\n");
    }
}

int main() {
    Variant var1, var2, var3;

    // 设置为整数
    var1.type = TYPE_INT;
    var1.value.i = 123;
    printVariant(&var1);

    // 设置为浮点数
    var2.type = TYPE_FLOAT;
    var2.value.f = 98.6f;
    printVariant(&var2);

    // 设置为字符串
    var3.type = TYPE_STRING;
    // 为安全起见，使用 snprintf
    snprintf(var3.value.s, sizeof(var3.value.s), "你好，标记联合!");
    printVariant(&var3);

    // 现在根据标记访问错误的成员的可能性降低了
    // （尽管如果程序员忽略标记，仍然可能发生）

    return 0;
}
```

**5. `union` 的适用场景**

联合不像结构体那样常用，但在特定场景下它们非常有益：

*   **节省内存（针对互斥数据）:** 这是主要的预期用途。当你有一个数据结构，并且你知道在任何时候只有其中几个可能的信息片段中的 *一个* 是相关的时，`union` 比 `struct`（会为 *所有* 成员分配空间）更能节省内存。这在以下情况特别有用：
    *   **嵌入式系统:** 内存通常非常受限。
    *   **大型数组:** 一个包含大型结构体的数组，如果每个元素只使用几个可能字段中的一个，会浪费大量内存。使用标记联合的数组会紧凑得多。

*   **实现变体类型（标记联合）:** 如上例所示，联合是创建可以持有不同、明确类型的值的变量的基础。这在以下方面很常见：
    *   解释器或编译器（表示可以是标识符、数字、操作符等的标记或抽象语法树节点）。
    *   泛型数据结构或容器。
    *   消息传递系统，其中消息可以有不同的数据格式。

*   **访问硬件寄存器（底层编程）:** 有时，一个硬件寄存器可以作为一个整体（例如，32位）被访问，也可以作为单独的位域或字节被访问。`union` 可以模拟这种情况：

    ```c
    union HWRegister {
        unsigned int full_reg; // 整个寄存器
        struct { // 按字节访问
            unsigned char byte0;
            unsigned char byte1;
            unsigned char byte2;
            unsigned char byte3;
        } bytes;
        struct { // 按位域访问
            unsigned int flag1 : 1; // 位域，占1位
            unsigned int flag2 : 1;
            unsigned int value : 14; // 占14位
            // ... 其他位域
        } bits;
    };
    // 允许通过 reg.full_reg, reg.bytes.byte1, 或 reg.bits.flag1 等方式
    // 访问相同的内存位置。
    // 注意：字节序（Endianness）和内存对齐/填充（Packing）会影响字节/位的顺序。
    ```

*   **类型双关 (Type Punning)（极其谨慎地使用）:** 故意写入一种类型并读取另一种类型，以检查原始的位模式（例如，通过将其作为 `int` 读取来查看 `float` 的 IEEE 754 表示）。
    *   **警告:** 这种做法常常依赖于**未定义行为 (Undefined Behavior)** 或 **实现定义的行为 (Implementation-defined Behavior)**。它违反了 C 语言的严格别名规则 (Strict Aliasing Rules)，可能会被编译器以不可预测的方式优化掉，或者在不同的架构或编译器设置下表现不同。
    *   **更安全的替代方案:** 为了检查位模式，通常更推荐使用 `memcpy` 将值复制到一个字符数组 (`unsigned char[]`) 中并检查字节，或者 *非常小心地* 使用指针转换（通常也是不可移植的），而不是直接使用联合进行类型双关，以确保可靠性。

**6. 总结与注意事项**

*   **何时使用 `union`:** 当你需要一个变量在不同时间持有多种可能类型中的 *一种*，并且关心内存效率时；或者在实现变体类型或某些底层硬件接口时。
*   **关键要求:** 你 *必须* 有一种方法来追踪哪个成员当前是活动的（通常通过外部结构体中的一个标记）。
*   **避免在以下情况使用 `union`:** 需要同时存储多个值（应使用 `struct`）。
*   **警惕:** 使用 `union` 进行类型双关，因为存在可移植性和未定义行为的风险。只有在你深刻理解其含义、编译器行为和目标架构，并能接受其脆弱性时才这样做。

本质上，`union` 是通过在同一内存空间覆盖不同数据类型来实现内存优化和类型灵活性的一种工具，但它需要程序员进行仔细的管理。
