//
//  main.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/16.
//

#include <stdio.h>

extern void ptr_c(void);
extern void char_c(void);
extern void struct_c(void);

//int main(int argc, const char * argv[]) {
////    call();
////    char_c();
//    struct_c();
//    return 0;
//}
