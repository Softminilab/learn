//
//  ptr_c.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/16.
//

#include <stdio.h>
#include <stdlib.h>

void create_array(int *array, size_t array_size, int (*get_next_value)(void)) {
    for (size_t i=0; i<array_size; i++) {
        array[i] = get_next_value();
    }
}

int rand_value(void) {
    return rand();
}

void ptr_c(void) {
    int array[10];
    create_array(array, 10, rand_value);
    for (size_t i=0; i<10; i++) {
        printf("%d\n", array[i]);
    }
}
